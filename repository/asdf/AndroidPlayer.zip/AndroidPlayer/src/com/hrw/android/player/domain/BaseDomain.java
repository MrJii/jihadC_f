package com.hrw.android.player.domain;

public class BaseDomain {

}
